@echo off
title Sistema AT - Consola de diagnostico
cd /d "%~dp0"
echo ============================================================
echo  Sistema AT v1.0 - modo consola de diagnostico
echo  Si el sistema no abre, el error aparecera aqui abajo.
echo ============================================================
echo.
py\python.exe main.py
echo.
echo (Sistema cerrado. Si ve un error arriba, reportelo con captura.)
pause
